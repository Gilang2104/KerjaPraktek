<template>
    <div class="p-4">
      <div>
        <components>
            <FormDaftarSiswa/>
        </components>
      </div>
    </div>
  </template>
  
  <script setup lang="ts">
  </script>
  
  <style scoped>
  </style>
  