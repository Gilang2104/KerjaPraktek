<script setup lang="ts">

</script>

<template>
  <NuxtLayout>
 <NuxtPage/>
  </NuxtLayout>
</template>
