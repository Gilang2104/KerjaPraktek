<template>

</template>

<script setup>
import { reactive } from 'vue';

const formdata =reactive({});

const submitForm =() =>
console.log(formdata)

</script>