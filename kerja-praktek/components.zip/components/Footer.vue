<!-- components/Footer.vue -->
<template>
    <footer class="bg-gray-200 p-4 text-center">
      <p>© 2024 Your Company. All rights reserved.</p>
    </footer>
  </template>
  
  <script setup>
  // Anda bisa menambahkan fungsionalitas JavaScript di sini jika diperlukan
  </script>
  
  <style scoped>
  /* Tambahkan gaya spesifik untuk footer di sini */
  </style>
  